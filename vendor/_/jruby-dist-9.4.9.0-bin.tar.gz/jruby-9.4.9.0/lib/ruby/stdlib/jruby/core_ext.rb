require 'jruby/core_ext/class'
require 'jruby/core_ext/string'
require 'jruby/core_ext/thread'