# Load built-in jruby/serialization library
JRuby::Util.load_ext("org.jruby.ext.jruby.JRubySerializationLibrary")
