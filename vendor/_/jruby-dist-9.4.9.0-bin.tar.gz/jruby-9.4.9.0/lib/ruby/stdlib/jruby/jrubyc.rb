require 'jruby/compiler'

# For compatibility with libraries that used it directly in 1.4-
JRubyCompiler = JRuby::Compiler