require 'libfixposix/binary'
require 'subspawn/posix'
