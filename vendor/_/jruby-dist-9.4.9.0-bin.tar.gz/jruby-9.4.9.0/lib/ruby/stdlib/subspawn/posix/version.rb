# frozen_string_literal: true

module SubSpawn
	class POSIX
		VERSION = "0.1.1"
	end
end
