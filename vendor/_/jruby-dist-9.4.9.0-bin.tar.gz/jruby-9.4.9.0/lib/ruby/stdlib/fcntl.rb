# Load built-in fcntl library
JRuby::Util.load_ext("org.jruby.ext.fcntl.FcntlLibrary")
