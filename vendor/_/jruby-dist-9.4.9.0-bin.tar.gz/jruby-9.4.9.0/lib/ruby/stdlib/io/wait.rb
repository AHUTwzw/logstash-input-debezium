require 'io/wait.jar'
JRuby::Util.load_ext("org.jruby.ext.io.wait.IOWaitLibrary")
