JRuby::Util.load_ext('org.jruby.ext.io.nonblock.IONonBlock')
