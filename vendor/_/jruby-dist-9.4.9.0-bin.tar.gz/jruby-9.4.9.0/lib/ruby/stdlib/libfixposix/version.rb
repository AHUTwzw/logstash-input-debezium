# frozen_string_literal: true
require_relative '../libfixposix'
require_relative '../libfixposix/ffi'
