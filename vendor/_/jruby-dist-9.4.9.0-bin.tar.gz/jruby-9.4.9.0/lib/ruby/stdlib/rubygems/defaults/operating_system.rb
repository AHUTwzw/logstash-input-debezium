# In order to avoid the exception from failing to load this file in rubygems.org,
# we just require our actual defaults file here. Repackagers may modify this file
# to do system-specific things.
require 'rubygems/defaults/jruby'